I've been seeing a lot of Covid related words being used as passwords on internal tests recently, so yes the wordlist that should never have been needed to be created is here.

Hope you find it useful.

Matt